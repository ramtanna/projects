package com.daily.accounting.service;

import java.util.Date;
import java.util.List;

import com.daily.accounting.dto.PartyNameUpdateRequest;
import com.daily.accounting.dto.TransactionRequest;
import com.daily.accounting.dto.TransactionResponse;
import com.daily.accounting.model.Balance;

public interface ITransactionService {

	TransactionResponse newTransaction(TransactionRequest request);
	
	List<String> getClients(String userId);
	
	void updatePartyName(PartyNameUpdateRequest request, String userId);
	
	void deleteTransaction(String userId, String transactionId);

	Balance getPreviousDayBalance(Date date, String userId);
	
}
