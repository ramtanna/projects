package com.daily.accounting.repository;

import java.util.Date;
import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.transaction.annotation.Transactional;

import com.daily.accounting.model.Transaction;
import com.daily.accounting.model.UserDetail;

public interface TransactionRepository extends JpaRepository<Transaction, Integer> {

	List<Transaction> findByUserDetailsAndDate(UserDetail userDetail, Date date);
	
	@Query(value = "SELECT distinct party_name FROM daily_accounting.transaction "
			+ "where user_details_user_id= ?1", nativeQuery = true)
	List<String> findClientsByUserId(String userId);

	
	@Query(value = "select * from daily_accounting.transaction "
			+ "where user_details_user_id= ?1 and party_name= ?2 and "
			+ "transaction_date >= ?3 and transaction_date <= ?4 "
			+ "order by transaction_date DESC;", nativeQuery = true)
	List<Transaction> getClientReport(String userId, String clientName, Date fromDate, Date toDate);
	
	@Transactional
	@Modifying
	@Query(value = "update transaction set party_name = ?2 where party_name = ?1 and user_details_user_id = ?3", nativeQuery = true)
	void updatePartyName(String oldPartyname, String newPartyName, String userId);
	
}
