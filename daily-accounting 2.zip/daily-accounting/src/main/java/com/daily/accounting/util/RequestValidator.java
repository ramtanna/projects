package com.daily.accounting.util;

import org.springframework.http.HttpStatus;
import org.springframework.util.StringUtils;

import com.daily.accounting.dto.PartyNameUpdateRequest;
import com.daily.accounting.dto.TransactionRequest;
import com.daily.accounting.exception.ApplicationException;

public class RequestValidator {

	public static void validateUserId(String userId){
		if(userId == null || StringUtils.isEmpty(userId)){
			throw new ApplicationException(ErrorCode.NULL_USER_ID, HttpStatus.BAD_REQUEST);
		}
	}
	
	public static void validateNewTransactionRequest(TransactionRequest request){
		
		if(request == null){
			throw new ApplicationException(ErrorCode.NULL_REQUEST_BODY, HttpStatus.BAD_REQUEST);
		}
		
		if(request.getPartyName() == null || StringUtils.isEmpty(request.getPartyName())){
			throw new ApplicationException(ErrorCode.NULL_THIRD_PARTY_NAME, HttpStatus.BAD_REQUEST);
		}
		
		if(request.getType() == null || StringUtils.isEmpty(request.getType())){
			throw new ApplicationException(ErrorCode.NULL_TRANSACTION_TYPE, HttpStatus.BAD_REQUEST);
		}
		
	}
	
	public static void validatePartyNameRenameRequest(PartyNameUpdateRequest request){
		
		if(request == null){
			throw new ApplicationException(ErrorCode.NULL_REQUEST_BODY, HttpStatus.BAD_REQUEST);
		}
		
		if(request.getOldPartyName() == null || StringUtils.isEmpty(request.getOldPartyName())){
			throw new ApplicationException(ErrorCode.INVALID_OLD_PARTY_NAME, HttpStatus.BAD_REQUEST);
		}
		
		if(request.getNewPartyName() == null || StringUtils.isEmpty(request.getNewPartyName())){
			throw new ApplicationException(ErrorCode.INVALID_NEW_PARTY_NAME, HttpStatus.BAD_REQUEST);
		}
		
	}
	
}
