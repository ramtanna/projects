package com.daily.accounting.dto;

import lombok.Data;

@Data
public class PartyNameUpdateRequest {

	private String oldPartyName;
	private String newPartyName;

}
