package com.daily.accounting.controller;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseStatus;
import org.springframework.web.bind.annotation.RestController;

import com.daily.accounting.dto.ClientsResponse;
import com.daily.accounting.service.IReportService;
import com.daily.accounting.service.ITransactionService;
import com.daily.accounting.service.IUserService;
import com.daily.accounting.util.RequestValidator;
import com.daily.accounting.util.Routes;

import lombok.extern.slf4j.Slf4j;

@Slf4j
@RestController
@RequestMapping(Routes.BASE_URL)
public class ReportingController {

	@Autowired
	IReportService reportService;
	
	@Autowired
	IUserService userService;
	
	@Autowired
	ITransactionService transactionService;
	
	@GetMapping
	@RequestMapping("/reports/{date}/users/{userId}")
	@ResponseStatus(HttpStatus.OK)
	public Object getReport(@Valid @PathVariable String date, @Valid @PathVariable String userId,
			 @RequestHeader(name="X-User-Id") String xUserId) {
		
		log.info("Retrieving Report for date : "+ date + " of user : "+ userId);
		
		RequestValidator.validateUserId(xUserId);
		
		return reportService.getDailyReport(date, userId, xUserId);
		
	}
	
	
	@GetMapping
	@RequestMapping("/users")
	@ResponseStatus(HttpStatus.OK)
	public Object getUsers(@RequestHeader(name="X-User-Id") String userId) {
		
		log.info("Fetching Companies of user : "+ userId);
		RequestValidator.validateUserId(userId);
		return userService.getUsers(userId);
		
	}
	
	@GetMapping
	@RequestMapping("/clients")
	@ResponseStatus(HttpStatus.OK)
	public Object getClients(@RequestHeader(name="X-User-Id") String userId) {
		log.info("Fetching Clients of user : "+ userId);
		RequestValidator.validateUserId(userId);
		ClientsResponse response = new ClientsResponse();
		response.setClients(transactionService.getClients(userId));
		return response;
	}
	
	
	@GetMapping
	@RequestMapping("/reports/users/{userId}/clients/{clientName}/from/{fromDate}/to/{toDate}")
	@ResponseStatus(HttpStatus.OK)
	public Object getTransactions(@PathVariable String fromDate, @PathVariable String toDate,
			@PathVariable String userId, @PathVariable String clientName, @RequestHeader(name="X-User-Id") String xUserId) {
		log.info("Fetching Transactions of user : "+ userId + " client = "+clientName);
		RequestValidator.validateUserId(xUserId);
		return reportService.getClientReport(userId, fromDate, toDate, clientName, xUserId);
	}
	
	
	
	@GetMapping
	@RequestMapping("/reports/dashboard/date/{date}")
	@ResponseStatus(HttpStatus.OK)
	public Object getDashbord(@PathVariable String date, @RequestHeader(name="X-User-Id") String xUserId) {
		log.info("Fetching Dashboard of user : "+ xUserId + " date = "+date);
		RequestValidator.validateUserId(xUserId);
		return reportService.getDashboard(xUserId, date);
	}
	
	
	
	@GetMapping
	@RequestMapping("/reports/users/{userId}/parties/balance")
	@ResponseStatus(HttpStatus.OK)
	public Object getPartyBalance(@PathVariable String userId, @RequestHeader(name="X-User-Id") String xUserId) {
		log.info("Party Balance of user : "+ xUserId + " userId = "+userId);
		RequestValidator.validateUserId(xUserId);
		return reportService.getPartiesBalance(xUserId, userId);
	}
	
	
	
	
}
