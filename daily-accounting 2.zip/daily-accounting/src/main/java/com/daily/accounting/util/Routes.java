package com.daily.accounting.util;

public class Routes {

	public static final String BASE_URL = "/accounting";
	public static final String TRANSACTION   = "/transaction";
	
}
