package com.daily.accounting.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseStatus;
import org.springframework.web.bind.annotation.RestController;

import com.daily.accounting.dto.PartyNameUpdateRequest;
import com.daily.accounting.dto.TransactionRequest;
import com.daily.accounting.dto.TransactionResponse;
import com.daily.accounting.service.ITransactionService;
import com.daily.accounting.util.RequestValidator;
import com.daily.accounting.util.Routes;

import lombok.extern.slf4j.Slf4j;

@Slf4j
@RestController
@RequestMapping(Routes.BASE_URL)
public class TransactionController {

	@Autowired
	ITransactionService transactionService;
	
	/**
	 * 
	 * @param request
	 * @param userId
	 * @return
	 */
	@PostMapping
	@RequestMapping(Routes.TRANSACTION)
	@ResponseStatus(HttpStatus.CREATED)
	public TransactionResponse newTransaction(@RequestBody TransactionRequest request, @RequestHeader(name="X-User-Id") String userId){
		log.info("Request Received for Transaction " + request.toString());
		
		RequestValidator.validateUserId(userId);
		RequestValidator.validateNewTransactionRequest(request);
		request.setUserId(userId);
		
		return transactionService.newTransaction(request);
	}
	
	
	@PutMapping
	@RequestMapping("/client/rename")
	public void renamePartyName(@RequestBody PartyNameUpdateRequest request, @RequestHeader(name="X-User-Id") String userId){
		RequestValidator.validateUserId(userId);
		RequestValidator.validatePartyNameRenameRequest(request);
		transactionService.updatePartyName(request, userId);
	}
	
	
	@DeleteMapping
	@RequestMapping(Routes.TRANSACTION+"/{transactionId}")
	@ResponseStatus(HttpStatus.OK)
	public void deleteTransaction(@PathVariable String transactionId, @RequestHeader(name="X-User-Id") String userId){
		log.info("delete Request Received for Transaction Id " + transactionId);
		RequestValidator.validateUserId(userId);
		transactionService.deleteTransaction(userId, transactionId);
	}
	
}
