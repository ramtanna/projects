package com.daily.accounting.model;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.OneToOne;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

import com.fasterxml.jackson.annotation.JsonIgnore;

import lombok.Data;

@Data
@Entity
public class Transaction {

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Integer id;
	
	@JsonIgnore
	@OneToOne
	private UserDetail userDetails;
	
	@Temporal(TemporalType.DATE)
	@Column(name="transaction_date")
	private Date date;
	
	@Column
	public String type;
	
	@Column
	private String partyName;
	
	@Column
	private Double cash;
	
	@Column
	private Double coin;
	
	@Column
	private Double total;
	
	@Column 
	private Date createdDate;
	
	@Column
	private String note;
	
	
}
