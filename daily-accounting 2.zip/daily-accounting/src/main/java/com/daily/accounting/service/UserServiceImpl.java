package com.daily.accounting.service;

import java.util.Arrays;
import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;
import org.springframework.util.StringUtils;

import com.daily.accounting.exception.ApplicationException;
import com.daily.accounting.model.UserDetail;
import com.daily.accounting.repository.UserRepository;
import com.daily.accounting.util.ErrorCode;

import lombok.extern.slf4j.Slf4j;

@Slf4j
@Service
public class UserServiceImpl implements IUserService{

	@Autowired
	UserRepository userRepository;
	
	@Override
	public UserDetail getUserDetails(String userId) {
		
		log.info("Fetching user details for user Id : " + userId);
		Optional<UserDetail> userOption = userRepository.findById(userId);
		
		if (!userOption.isPresent()) {
			throw new ApplicationException(ErrorCode.INVALID_USER, HttpStatus.BAD_REQUEST);
		}
		
		UserDetail userDetail = userOption.get();
		return userDetail;
	}

	@Override
	public List<UserDetail> getUsers(String userId) {
		UserDetail userDetail = getUserDetails(userId);
		if(userDetail.getOwner() == null || StringUtils.isEmpty(userDetail.getOwner())){
			return null;
		}
		return userRepository.findByUserIdIn(Arrays.asList(userDetail.getOwner().split(",")));
	}
	
}
