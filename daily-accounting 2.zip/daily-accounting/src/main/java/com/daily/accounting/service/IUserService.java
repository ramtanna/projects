package com.daily.accounting.service;

import java.util.List;

import com.daily.accounting.model.UserDetail;

public interface IUserService {

	public UserDetail getUserDetails(String userId);
	
	public List<UserDetail> getUsers(String userId);
	
}
