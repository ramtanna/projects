package com.daily.accounting.dto;

import java.util.Date;
import java.util.List;

import com.daily.accounting.model.Transaction;
import com.fasterxml.jackson.annotation.JsonFormat;

import lombok.Data;

@Data
public class DailyReportResponse {

	private String userId;
	private String name;
	@JsonFormat(pattern="yyyy-MM-dd")
	private Date date;
	private Double cashOpeningBalance;
	private Double cashClosingBalance;
	private Double coinOpeningBalance;
	private Double coinClosingBalance;
	private Double totalOpeningBalance;
	private Double totalClosingBalance;
	private List<Transaction> credits;
	private List<Transaction> debits;
	private String lastEntryTime;
}
