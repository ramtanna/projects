package com.daily.accounting.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;

import com.daily.accounting.model.UserDetail;

public interface UserRepository extends JpaRepository<UserDetail, String> {
	
	List<UserDetail> findByUserIdIn(List<String> userIds);

}
