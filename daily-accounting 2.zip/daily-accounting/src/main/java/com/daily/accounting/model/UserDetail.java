package com.daily.accounting.model;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;

import com.fasterxml.jackson.annotation.JsonIgnore;

import lombok.Data;

@Data
@Entity
public class UserDetail {

	public UserDetail() {
		super();
	}

	public UserDetail(String userId) {
		super();
		this.userId = userId;
	}

	@Id
	private String userId;
	
	@Column
	private String name;
	
	@JsonIgnore
	@Column
	private String password;
	
	@Column
	private String owner;
	
}
