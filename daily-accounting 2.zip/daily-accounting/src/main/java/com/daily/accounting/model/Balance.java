package com.daily.accounting.model;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.OneToOne;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

import lombok.Data;

@Data
@Entity
public class Balance {

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Integer id;

	@Temporal(TemporalType.DATE)
	@Column(name = "b_date")
	private Date date;

	@OneToOne
	private UserDetail userDetails;

	
	@Column
	private Double cashOpeningBalance;

	@Column
	private Double coinOpeningBalance;

	@Column
	private Double totalOpeningBalance;

	@Column
	private Double cashClosingBalance;

	@Column
	private Double coinClosingBalance;

	@Column
	private Double totalClosingBalance;
	
	@Column 
	private Date lastEntryTime;

}
