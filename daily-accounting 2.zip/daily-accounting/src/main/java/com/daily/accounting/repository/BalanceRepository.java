package com.daily.accounting.repository;

import java.util.Date;
import java.util.List;
import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import com.daily.accounting.model.Balance;
import com.daily.accounting.model.UserDetail;

public interface BalanceRepository extends JpaRepository<Balance, Integer> {

	Optional<Balance> findByDateAndUserDetails(Date date,UserDetail user);
	
	@Query(value = "select * from balance where b_date < ?1 and user_details_user_id =?2 order by b_date DESC LIMIT 1", nativeQuery = true)
	List<Balance> findBalanceByDateAndUserId(@Param("date") Date date , @Param("userId") String userId);
	
	@Query(value = "SELECT * FROM daily_accounting.balance where b_date > ?1 and user_details_user_id = ?2", nativeQuery = true)
	List<Balance> getFutureBalance(Date date , String userId);
	
	List<Balance> findByDateAndUserDetailsIn(Date date, List<UserDetail> userIds);
	
	
	@Query(value = "SELECT party_name partyName, user_details_user_id userId, SUM(COALESCE(CASE WHEN type = 'CREDIT' THEN total END,0)) totalCredits "
			+ " , SUM(COALESCE(CASE WHEN type = 'DEBIT' THEN total END,0)) totalDebits "
			+ " , SUM(COALESCE(CASE WHEN type = 'CREDIT' THEN total END,0))  "
			+ " - SUM(COALESCE(CASE WHEN type = 'DEBIT' THEN total END,0)) balance "
			+ " FROM daily_accounting.transaction where user_details_user_id = ?1 " + " GROUP   "
			+ " BY party_name", nativeQuery = true)
	List<PartiesBalanceStatistics> getpartiesBalance(String userId);
	
}
