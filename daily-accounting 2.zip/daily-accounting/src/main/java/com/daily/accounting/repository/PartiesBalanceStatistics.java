package com.daily.accounting.repository;

public interface PartiesBalanceStatistics {

	
	 String getPartyName();
	 Double getTotalCredits();
	 Double getTotalDebits();
	 Double getBalance();
	 String getUserId();
	
}