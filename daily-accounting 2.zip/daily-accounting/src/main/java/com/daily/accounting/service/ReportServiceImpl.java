package com.daily.accounting.service;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.stream.Collectors;

import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;

import com.daily.accounting.dto.DailyReportResponse;
import com.daily.accounting.exception.ApplicationException;
import com.daily.accounting.model.Balance;
import com.daily.accounting.model.Transaction;
import com.daily.accounting.model.UserDetail;
import com.daily.accounting.repository.BalanceRepository;
import com.daily.accounting.repository.PartiesBalanceStatistics;
import com.daily.accounting.repository.TransactionRepository;
import com.daily.accounting.repository.UserRepository;
import com.daily.accounting.util.ErrorCode;
import com.daily.accounting.util.TransactionType;

import lombok.extern.slf4j.Slf4j;

@Slf4j
@Service
public class ReportServiceImpl implements IReportService{

	@Autowired
	TransactionRepository transactionRepository;

	@Autowired
	UserRepository userRepository;
	
	@Autowired
	IUserService userService;

	@Autowired
	BalanceRepository balanceRepository;
	
	@Autowired
	ITransactionService transactionService;
	
	@Override
	public DailyReportResponse getDailyReport(String reportDate, String userId, String xUserId) {

		log.info("Fetching Balance Report for User ID : " + userId);
		log.info("Report requested by " + xUserId + "for User ID : " + userId);
		
		Date date = null;
		try {
			date = new SimpleDateFormat("yyyy-MM-dd").parse(reportDate);
		} catch (ParseException e) {
			throw new ApplicationException(ErrorCode.DATE_PARSE_EXCEPTION, HttpStatus.BAD_REQUEST);
		}
		
		if(!isAccessible(userId, xUserId)){
			throw new ApplicationException(ErrorCode.NO_ACCESS, HttpStatus.BAD_REQUEST); 
		}
		
		Optional<Balance> balanceOption = balanceRepository.findByDateAndUserDetails(date, new UserDetail(userId));
		
		if (!balanceOption.isPresent()) {
			throw new ApplicationException(ErrorCode.NO_RECORD_FOR_GIVEN_DATE, HttpStatus.BAD_REQUEST);
		}
		Balance balance = balanceOption.get();
		
		
		DailyReportResponse dailyReportResponse = new DailyReportResponse();
		
		List<Transaction> transactions = transactionRepository.findByUserDetailsAndDate(new UserDetail(userId), date);
		 
		Map<String, List<Transaction>> transactionsByType = 
				transactions.stream().collect(Collectors.groupingBy(Transaction::getType));
		
		if(transactionsByType.containsKey(TransactionType.CREDIT.name())){
			dailyReportResponse.setCredits(transactionsByType.get(TransactionType.CREDIT.name()));
		}
		if(transactionsByType.containsKey(TransactionType.DEBIT.name())){
			dailyReportResponse.setDebits(transactionsByType.get(TransactionType.DEBIT.name()));
		}
		
		BeanUtils.copyProperties(balance, dailyReportResponse);
		dailyReportResponse.setUserId(userId);
		dailyReportResponse.setDate(date);
		
		return dailyReportResponse;
	}

	
	/**
	 * 
	 * @param userId - User for which report is requested
	 * @param xUserId - User who has requested the report.
	 * @return
	 */
	private boolean isAccessible(String userId, String xUserId){
		
		if(userId.equalsIgnoreCase(xUserId)){
			return true;
		}
		
		UserDetail userDetail = userService.getUserDetails(xUserId);
		
		String users[] = userDetail.getOwner().split(",");
		for(int i=0;i<users.length;i++){
			if(users[i].equalsIgnoreCase(userId)){
				return true;
			}
		}
		return false;
	}


	@Override
	public List<Transaction> getClientReport(String userId, String fDate, String tDate, String clientName,
			String xUserId) {

		SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
		Date fromDate = null;
		Date toDate = null;
		try {
			fromDate = sdf.parse(fDate);
			toDate = sdf.parse(tDate);
		} catch (ParseException e) {
			throw new ApplicationException(ErrorCode.DATE_PARSE_EXCEPTION, HttpStatus.BAD_REQUEST);
		}
		
		
		if(!isAccessible(userId, xUserId)){
			throw new ApplicationException(ErrorCode.NO_ACCESS, HttpStatus.BAD_REQUEST); 
		}
		
		List<Transaction> transactions = transactionRepository.getClientReport(userId, clientName, fromDate, toDate);
		return transactions;
	}


	@Override
	public List<DailyReportResponse> getDashboard(String userId, String requestDate) {

		Date date = null;
		try {
			date = new SimpleDateFormat("yyyy-MM-dd").parse(requestDate);
		} catch (ParseException e) {
			throw new ApplicationException(ErrorCode.DATE_PARSE_EXCEPTION, HttpStatus.BAD_REQUEST);
		}
		
		UserDetail userDetail = userService.getUserDetails(userId);
		List<UserDetail> users = new ArrayList<>();
		users.add(new UserDetail(userId));
		
		if(userDetail.getOwner() != null){
			String userArray[] = userDetail.getOwner().split(",");
			
			for(int i=0;i<userArray.length;i++){
				users.add(new UserDetail(userArray[i]));
			}
		}
		
		List<Balance> balanceList = balanceRepository.findByDateAndUserDetailsIn(date, users);
		
		List<DailyReportResponse> response = new ArrayList<>();
		
		for(Balance balance : balanceList){
			DailyReportResponse dailyReportResponse = new DailyReportResponse();
			BeanUtils.copyProperties(balance, dailyReportResponse);
			BeanUtils.copyProperties(balance.getUserDetails(), dailyReportResponse);
			response.add(dailyReportResponse);
		}
		
		//issue no. 3 changes starts here
		if(balanceList.size()!=users.size()){
			
			for(UserDetail user : users){

				boolean isUserDetailsPresent=false;
				for(Balance balance : balanceList){
					if(balance.getUserDetails().getUserId().equalsIgnoreCase(user.getUserId())){
						isUserDetailsPresent = true;
						break;
					}
				}
				
				Balance balance = null;
				if(!isUserDetailsPresent){
					Balance prevDay = transactionService.getPreviousDayBalance(date, user.getUserId());
					balance = new Balance();
					balance.setUserDetails(new UserDetail(user.getUserId()));
					balance.setDate(date);
					balance.setCashOpeningBalance(prevDay.getCashClosingBalance());
					balance.setCoinOpeningBalance(prevDay.getCoinClosingBalance());
					balance.setTotalOpeningBalance(prevDay.getTotalClosingBalance());
					balance.setCashClosingBalance(prevDay.getCashClosingBalance());
					balance.setCoinClosingBalance(prevDay.getCoinClosingBalance());
					balance.setTotalClosingBalance(prevDay.getTotalClosingBalance());
					balanceRepository.save(balance);
					DailyReportResponse dailyReportResponse = new DailyReportResponse();
					BeanUtils.copyProperties(balance, dailyReportResponse);
					BeanUtils.copyProperties(balance.getUserDetails(), dailyReportResponse);
					response.add(dailyReportResponse);
				}
			
			}
			
		}
		
		return response;
	}


	@Override
	public List<PartiesBalanceStatistics> getPartiesBalance(String xUserId, String userId) {
		
		if(!isAccessible(userId, xUserId)){
			throw new ApplicationException(ErrorCode.NO_ACCESS, HttpStatus.BAD_REQUEST); 
		}
//		balanceRepository.getpartiesBalance(userId);
		return balanceRepository.getpartiesBalance(userId);
	}
	
}
