package com.daily.accounting.dto;

import java.util.Date;

import com.fasterxml.jackson.annotation.JsonFormat;

import lombok.Data;

@Data
public class TransactionResponse {

	private int id;
	
	@JsonFormat(pattern = "yyyy-MM-dd")
	private Date date;
	
	private String userId;
	
	private String name;
	
	private String type;
	
	private String partyName;
	
	private String note;
	
	private double cash;
	
	private double coin;
	
	private double total;
	
	private Double cashOpeningBalance;

	private Double coinOpeningBalance;

	private Double totalOpeningBalance;

	private Double cashClosingBalance;

	private Double coinClosingBalance;

	private Double totalClosingBalance;
}
