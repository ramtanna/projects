package com.daily.accounting.exception;

import java.util.Date;

import lombok.Data;

@Data
public class ErrorDetails {

	private String errorCode;
	private String message;
	private String details;
	private Date timestamp;
	
	public ErrorDetails(Date timestamp, String message, String details, String errorCode) {
		super();
		this.timestamp = timestamp;
		this.message = message;
		this.details = details;
		this.errorCode = errorCode;
	}
	
}
