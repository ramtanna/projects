package com.daily.accounting.dto;

import java.util.ArrayList;
import java.util.List;

import lombok.Data;

@Data
public class ClientsResponse {

	List<String> clients = new ArrayList<>();
}
