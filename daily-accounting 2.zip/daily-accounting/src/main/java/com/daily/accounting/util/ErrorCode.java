package com.daily.accounting.util;

public interface ErrorCode {

	
//	public static final String NO_DRIVER_FOUND = "LNCAB0002";
	public static final String NULL_TRANSACTION_DATE = "DA0003";
	
	public static final String NULL_USER_ID = "LNCAB0004";
	public static final String NULL_REQUEST_BODY = "LNCAB0007";
	public static final String NULL_TRANSACTION_TYPE = "LNCAB0005";
	public static final String NULL_THIRD_PARTY_NAME = "LNCAB0006";
	public static final String INVALID_USER = "LNCAB0001";
	public static final String DATE_PARSE_EXCEPTION = "LNCAB0008";
	public static final String NO_ACCESS = "LNCAB0009";
	public static final String NO_RECORD_FOR_GIVEN_DATE = "LNCAB0010";
	public static final String INVALID_OLD_PARTY_NAME = "LNCAB0011";
	public static final String INVALID_NEW_PARTY_NAME = "LNCAB0012";
	public static final String INVALID_TRANSACTION_ID = "LNCAB0013";
}
