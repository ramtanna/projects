package com.daily.accounting.util;

public enum TransactionType {

	CREDIT,DEBIT;
}
