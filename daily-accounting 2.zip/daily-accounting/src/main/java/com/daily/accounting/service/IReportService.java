package com.daily.accounting.service;

import java.util.List;

import com.daily.accounting.dto.DailyReportResponse;
import com.daily.accounting.model.Transaction;
import com.daily.accounting.repository.PartiesBalanceStatistics;

public interface IReportService {

	DailyReportResponse getDailyReport(String date, String userId, String xUserId);
	
	List<Transaction> getClientReport(String userId, String fromDate, String toDate, String clientName, String xUserId);
	
	List<DailyReportResponse> getDashboard(String userId, String date);
	
	List<PartiesBalanceStatistics> getPartiesBalance(String xUserId, String userId);
}
