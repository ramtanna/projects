package com.daily.accounting.service;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;
import java.util.Optional;

import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;

import com.daily.accounting.dto.PartyNameUpdateRequest;
import com.daily.accounting.dto.TransactionRequest;
import com.daily.accounting.dto.TransactionResponse;
import com.daily.accounting.exception.ApplicationException;
import com.daily.accounting.model.Balance;
import com.daily.accounting.model.Transaction;
import com.daily.accounting.model.UserDetail;
import com.daily.accounting.repository.BalanceRepository;
import com.daily.accounting.repository.TransactionRepository;
import com.daily.accounting.repository.UserRepository;
import com.daily.accounting.util.DailyAccountingUtil;
import com.daily.accounting.util.ErrorCode;
import com.daily.accounting.util.TransactionType;

import lombok.extern.slf4j.Slf4j;

@Slf4j
@Service
public class TransactionServiceImpl implements ITransactionService {

	@Autowired
	TransactionRepository transactionRepository;

	@Autowired
	UserRepository userRepository;

	@Autowired
	BalanceRepository balanceRepository;

	@Override
	public TransactionResponse newTransaction(TransactionRequest request) {

		log.info("Fetching User Details for User ID : " + request.getUserId());

		Optional<UserDetail> userOption = userRepository.findById(request.getUserId());
		if (!userOption.isPresent()) {
			throw new ApplicationException(ErrorCode.INVALID_USER, HttpStatus.BAD_REQUEST);
		}
		UserDetail userDetail = userOption.get();

		log.info("Fetching Balance Report for User ID : " + request.getUserId() + " and Date : " + request.getDate());

		if (request.getDate() == null) {
			try {
				request.setDate(new SimpleDateFormat("yyyy-MM-dd").parse(new SimpleDateFormat("yyyy-MM-dd").format(new Date())));
			} catch (ParseException e) {
				throw new ApplicationException(ErrorCode.DATE_PARSE_EXCEPTION, HttpStatus.BAD_REQUEST);
			}
		}

		Balance balance = null;
		Optional<Balance> balanceOption = balanceRepository.findByDateAndUserDetails(request.getDate(), new UserDetail(request.getUserId()));
		if (!balanceOption.isPresent()) {
			log.info("Balance report not exist of user : " + request.getUserId() + " and Date : " + request.getDate());
			Balance prevDay = getPreviousDayBalance(request.getDate(), request.getUserId());
			balance = new Balance();
			balance.setUserDetails(new UserDetail(request.getUserId()));
			balance.setDate(request.getDate());
			balance.setCashOpeningBalance(prevDay.getCashClosingBalance());
			balance.setCoinOpeningBalance(prevDay.getCoinClosingBalance());
			balance.setTotalOpeningBalance(prevDay.getTotalClosingBalance());
			balance.setCashClosingBalance(prevDay.getCashClosingBalance());
			balance.setCoinClosingBalance(prevDay.getCoinClosingBalance());
			balance.setTotalClosingBalance(prevDay.getTotalClosingBalance());
		} else {
			balance = balanceOption.get();
		}

		double total = request.getCash() + request.getCoin();

		if (request.getType().equalsIgnoreCase(TransactionType.CREDIT.name())) {
			balance.setCashClosingBalance(DailyAccountingUtil.decimalRound(balance.getCashClosingBalance() + request.getCash()));
			balance.setCoinClosingBalance(DailyAccountingUtil.decimalRound(balance.getCoinClosingBalance() + request.getCoin()));
			balance.setTotalClosingBalance(DailyAccountingUtil.decimalRound(balance.getTotalClosingBalance() + total));
		} else if (request.getType().equalsIgnoreCase(TransactionType.DEBIT.name())) {
			balance.setCashClosingBalance(DailyAccountingUtil.decimalRound(balance.getCashClosingBalance() - request.getCash()));
			balance.setCoinClosingBalance(DailyAccountingUtil.decimalRound(balance.getCoinClosingBalance() - request.getCoin()));
			balance.setTotalClosingBalance(DailyAccountingUtil.decimalRound(balance.getTotalClosingBalance() - total));
		}

		Transaction transaction = new Transaction();
		Date currDate = new Date();
		BeanUtils.copyProperties(request, transaction);
		transaction.setUserDetails(userDetail);
		transaction.setTotal(total);
		transaction.setCreatedDate(currDate);
		balance.setLastEntryTime(currDate);
		
		transactionRepository.save(transaction);
		balanceRepository.save(balance);
		
		updateFutureDatesBalance(request);

		TransactionResponse response = new TransactionResponse();
		BeanUtils.copyProperties(balance, response);
		BeanUtils.copyProperties(transaction, response);
		BeanUtils.copyProperties(balance.getUserDetails(), response);

		log.info("Transaction successful for user : " + response.getUserId());
		
		return response;
	}

	@Override
	public Balance getPreviousDayBalance(Date date, String userId) {

		log.info("Getting previous day report : " + userId + " and Date : " + date);

		List<Balance> balanceOption = balanceRepository.findBalanceByDateAndUserId(date, userId);

		Balance balance = null;
		if (balanceOption.isEmpty()) {
			log.info("No records exist");
			balance = new Balance();
//			balance.setUser
			balance.setDate(new Date());
			balance.setCashClosingBalance((double) 0);
			balance.setCoinClosingBalance((double) 0);
			balance.setTotalClosingBalance((double) 0);
			balance.setCashOpeningBalance((double) 0);
			balance.setCoinOpeningBalance((double) 0);
			balance.setTotalOpeningBalance((double) 0);
		} else {
			balance = balanceOption.get(0);
			log.info("Balance report fetched of date : " + balance.getDate());
		}
		return balance;

	}

	@Override
	public List<String> getClients(String userId) {

		List<String> clients = transactionRepository.findClientsByUserId(userId);
		return clients;
	}
	
	private void updateFutureDatesBalance(TransactionRequest request){

	List<Balance> balanceList = balanceRepository.getFutureBalance(request.getDate(), request.getUserId());
	
	for(Balance balance : balanceList){
		
		double total = request.getCash() + request.getCoin();
		
		if (request.getType().equalsIgnoreCase(TransactionType.CREDIT.name())) {
			balance.setCashOpeningBalance(DailyAccountingUtil.decimalRound(balance.getCashOpeningBalance() + request.getCash()));
			balance.setCoinOpeningBalance(DailyAccountingUtil.decimalRound(balance.getCoinOpeningBalance() + request.getCoin()));
			balance.setTotalOpeningBalance(DailyAccountingUtil.decimalRound(balance.getTotalOpeningBalance() + total));
			balance.setCashClosingBalance(DailyAccountingUtil.decimalRound(balance.getCashClosingBalance() + request.getCash()));
			balance.setCoinClosingBalance(DailyAccountingUtil.decimalRound(balance.getCoinClosingBalance() + request.getCoin()));
			balance.setTotalClosingBalance(DailyAccountingUtil.decimalRound(balance.getTotalClosingBalance() + total));
		} else if (request.getType().equalsIgnoreCase(TransactionType.DEBIT.name())) {
			balance.setCashOpeningBalance(DailyAccountingUtil.decimalRound(balance.getCashOpeningBalance() - request.getCash()));
			balance.setCoinOpeningBalance(DailyAccountingUtil.decimalRound(balance.getCoinOpeningBalance() - request.getCoin()));
			balance.setTotalOpeningBalance(DailyAccountingUtil.decimalRound(balance.getTotalOpeningBalance() - total));
			balance.setCashClosingBalance(DailyAccountingUtil.decimalRound(balance.getCashClosingBalance() - request.getCash()));
			balance.setCoinClosingBalance(DailyAccountingUtil.decimalRound(balance.getCoinClosingBalance() - request.getCoin()));
			balance.setTotalClosingBalance(DailyAccountingUtil.decimalRound(balance.getTotalClosingBalance() - total));
		}
		
		balanceRepository.save(balance);
		
	}
	
	
	}

	@Override
	public void updatePartyName(PartyNameUpdateRequest request, String userId) {
		transactionRepository.updatePartyName(request.getOldPartyName(), request.getNewPartyName(), userId);
	}

	@Override
	public void deleteTransaction(String userId, String transactionId) {

		Optional<Transaction> transactionOption = transactionRepository.findById(Integer.parseInt(transactionId));
		if (!transactionOption.isPresent()) {
			throw new ApplicationException(ErrorCode.INVALID_TRANSACTION_ID, HttpStatus.BAD_REQUEST);
		}
		
		Transaction transaction = transactionOption.get();
		
		if(!userId.equalsIgnoreCase(transaction.getUserDetails().getUserId())){
			throw new ApplicationException(ErrorCode.INVALID_USER, HttpStatus.BAD_REQUEST);
		}
		
		Optional<Balance> balanceOption = balanceRepository.findByDateAndUserDetails(transaction.getDate(), transaction.getUserDetails());
		Balance balance = balanceOption.get();
		
		TransactionRequest oldTransaction = new TransactionRequest();
		BeanUtils.copyProperties(transaction, oldTransaction);
		oldTransaction.setUserId(transaction.getUserDetails().getUserId());
		double total = oldTransaction.getCash() + oldTransaction.getCoin();
		
		if(transaction.getType().equalsIgnoreCase(TransactionType.CREDIT.name())){
			oldTransaction.setType(TransactionType.DEBIT.name());
			balance.setCashClosingBalance(DailyAccountingUtil.decimalRound(balance.getCashClosingBalance() - oldTransaction.getCash()));
			balance.setCoinClosingBalance(DailyAccountingUtil.decimalRound(balance.getCoinClosingBalance() - oldTransaction.getCoin()));
			balance.setTotalClosingBalance(DailyAccountingUtil.decimalRound(balance.getTotalClosingBalance() - total));
		}
		else{
			oldTransaction.setType(TransactionType.CREDIT.name());
			balance.setCashClosingBalance(DailyAccountingUtil.decimalRound(balance.getCashClosingBalance() + oldTransaction.getCash()));
			balance.setCoinClosingBalance(DailyAccountingUtil.decimalRound(balance.getCoinClosingBalance() + oldTransaction.getCoin()));
			balance.setTotalClosingBalance(DailyAccountingUtil.decimalRound(balance.getTotalClosingBalance() + total));
		}
		
		balanceRepository.save(balance);
		updateFutureDatesBalance(oldTransaction);
		
		transactionRepository.delete(transaction);
		
	}
	

}
