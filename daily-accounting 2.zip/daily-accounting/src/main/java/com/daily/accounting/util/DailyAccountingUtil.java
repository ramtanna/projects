package com.daily.accounting.util;

import java.text.DecimalFormat;

public class DailyAccountingUtil {

	private static DecimalFormat df = new DecimalFormat(".##");

	public static Double decimalRound(Double d) {
		return Double.parseDouble(df.format(d));
	}

}
