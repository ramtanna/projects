package com.daily.accounting.exception;

import java.util.Date;
import java.util.Locale;
import java.util.ResourceBundle;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Component;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.context.request.WebRequest;
import org.springframework.web.servlet.mvc.method.annotation.ResponseEntityExceptionHandler;

import lombok.extern.slf4j.Slf4j;

@Slf4j
@ControllerAdvice
@Component
public class CustomizedResponseEntityExceptionHandler extends ResponseEntityExceptionHandler {

	private final String ERROR_SOURCE = "error_messages";
	
	
	@ExceptionHandler(ApplicationException.class)
	public final ResponseEntity<ErrorDetails> handleInvalidCustomerException(ApplicationException ex,
			WebRequest request) {
		String message = ResourceBundle.getBundle(ERROR_SOURCE, Locale.ROOT).getString(ex.getErrorCode());
		ErrorDetails errorDetails = new ErrorDetails(new Date(), message, request.getDescription(true),
				ex.getErrorCode());
		log.error(errorDetails.toString());
		ex.printStackTrace();
		return new ResponseEntity<>(errorDetails, ex.getHttpStatus());
	}

//	@ExceptionHandler(InvalidUserException.class)
//	public final ResponseEntity<ErrorDetails> handleInvalidCustomerException(InvalidUserException ex,
//			WebRequest request) {
//		String message = ResourceBundle.getBundle(ERROR_SOURCE, Locale.ROOT).getString(ex.getErrorCode());
//		ErrorDetails errorDetails = new ErrorDetails(new Date(), message, request.getDescription(false),
//				ex.getErrorCode());
//		return new ResponseEntity<>(errorDetails, HttpStatus.BAD_REQUEST);
//	}

//	@ExceptionHandler(DriverNotFoundException.class)
//	public final ResponseEntity<ErrorDetails> handleDriverNotFoundException(DriverNotFoundException ex,
//			WebRequest request) {
//		String message = ResourceBundle.getBundle(ERROR_SOURCE, Locale.ROOT).getString(ex.getErrorCode());
//		ErrorDetails errorDetails = new ErrorDetails(new Date(), message, request.getDescription(false),
//				ex.getErrorCode());
//		return new ResponseEntity<>(errorDetails, HttpStatus.NOT_FOUND);
//	}

//	@Override
//	protected ResponseEntity<Object> handleMethodArgumentNotValid(MethodArgumentNotValidException ex,
//			HttpHeaders headers, HttpStatus status, WebRequest request) {
//
//		List<String> errorCodes = new ArrayList<String>();
//		List<String> errorMessages = new ArrayList<String>();
//		for (ObjectError objectError : ex.getBindingResult().getAllErrors()) {
//			errorCodes.add(objectError.getDefaultMessage());
//			errorMessages.add(ResourceBundle.getBundle(ERROR_SOURCE, Locale.ROOT).getString(objectError.getDefaultMessage()));
//
//		}
//		ErrorsDetails errorDetails = new ErrorsDetails(new Date(), errorMessages, 
//				request.getDescription(false), errorCodes);
//
//		return new ResponseEntity(errorDetails, HttpStatus.BAD_REQUEST);
//	}
	
	
	

}
