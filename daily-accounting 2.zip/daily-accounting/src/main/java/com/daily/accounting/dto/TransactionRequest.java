package com.daily.accounting.dto;

import java.util.Date;

import javax.validation.constraints.NotNull;

import com.daily.accounting.util.ErrorCode;
import com.fasterxml.jackson.annotation.JsonFormat;
import com.fasterxml.jackson.annotation.JsonIgnore;

import lombok.Data;

@Data
public class TransactionRequest {

	@JsonFormat(pattern = "yyyy-MM-dd")
	private Date date;
	
	@JsonIgnore
//	@NotNull(message=ErrorCode.NULL_USER_ID)
	private String userId;
	
	@NotNull(message=ErrorCode.NULL_TRANSACTION_TYPE)
	private String type;
	
	@NotNull(message=ErrorCode.NULL_THIRD_PARTY_NAME)
	private String partyName;
	
	private double cash;
	
	private double coin;
	
	private String note;
	
}
