

create database daily_accounting;
use daily_accounting;


create table balance (id integer not null auto_increment, cash_closing_balance double precision, cash_opening_balance double precision, coin_closing_balance double precision, coin_opening_balance double precision, b_date date, total_closing_balance double precision, total_opening_balance double precision, user_details_user_id varchar(255), primary key (id)) engine=InnoDB;
create table transaction (id integer not null auto_increment, cash double precision, coin double precision, created_date datetime, transaction_date date, party_name varchar(255), total double precision, type varchar(255), user_details_user_id varchar(255), primary key (id)) engine=InnoDB;
create table user_detail (user_id varchar(255) not null, name varchar(255), owner varchar(255), password varchar(255), primary key (user_id)) engine=InnoDB;
alter table balance add constraint FKm13mrxmsrpg8l8jfnlt8tqw3o foreign key (user_details_user_id) references user_detail (user_id);
alter table transaction add constraint FKo8m1do67hftpe05dhfhw8kxus foreign key (user_details_user_id) references user_detail (user_id);

INSERT INTO `daily_accounting`.`user_detail` (`user_id`, `name`, `password`) VALUES ('dk', 'Dhawal Khimani', '123456')


