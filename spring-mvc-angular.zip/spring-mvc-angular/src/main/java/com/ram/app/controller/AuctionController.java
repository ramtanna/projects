package com.ram.app.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseStatus;
import org.springframework.web.bind.annotation.RestController;

import com.ram.app.dto.PlayerBidDTO;
import com.ram.app.dto.TeamDTO;
import com.ram.app.model.Player;
import com.ram.app.service.IAuctionService;

@RestController
@RequestMapping(AuctionController.BASE_URL)
public class AuctionController {

	public static final String BASE_URL = "/auction";
	
	@Autowired
	private IAuctionService auctionService;
	
	@PostMapping
	@RequestMapping("/purchase/{playerId}")
	@ResponseStatus(HttpStatus.OK)
	public Player bid(@PathVariable Long playerId, @RequestBody PlayerBidDTO player) {
		
		auctionService.purchasePlayer(playerId, player);
		return null;
	}
	
	
	@GetMapping
	@RequestMapping("/tournaments/{tournamentId}/teams/{teamId}")
	@ResponseStatus(HttpStatus.OK)
	public TeamDTO getTeam(@PathVariable Long tournamentId, @PathVariable Long teamId){
//		auctionService.getDashboard(tournamentId);
		return auctionService.getTeam(tournamentId, teamId);
	}
	
	@GetMapping
	@RequestMapping("/tournaments/{tournamentId}/teams")
	@ResponseStatus(HttpStatus.OK)
	public List<TeamDTO> getDashboard(@PathVariable Long tournamentId){
		return auctionService.getTeamDashboard(tournamentId);
	}
	
}
