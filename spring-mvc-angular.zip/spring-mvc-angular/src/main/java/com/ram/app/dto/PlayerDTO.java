package com.ram.app.dto;

import com.ram.app.util.PlayerCategoryEnum;

public class PlayerDTO {

	private Long playerId;
	private String playerName;
	private PlayerCategoryEnum category;
	private String status;
	private double sellingPrice;
	
	public Long getPlayerId() {
		return playerId;
	}
	public void setPlayerId(Long playerId) {
		this.playerId = playerId;
	}
	public String getPlayerName() {
		return playerName;
	}
	public void setPlayerName(String playerName) {
		this.playerName = playerName;
	}
	public PlayerCategoryEnum getCategory() {
		return category;
	}
	public void setCategory(PlayerCategoryEnum category) {
		this.category = category;
	}
	public String getStatus() {
		return status;
	}
	public void setStatus(String status) {
		this.status = status;
	}
	public double getSellingPrice() {
		return sellingPrice;
	}
	public void setSellingPrice(double sellingPrice) {
		this.sellingPrice = sellingPrice;
	}
	
	
	
}
