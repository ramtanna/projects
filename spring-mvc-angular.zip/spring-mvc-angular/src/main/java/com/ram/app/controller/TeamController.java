package com.ram.app.controller;

import java.util.List;
import java.util.stream.Collectors;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseStatus;
import org.springframework.web.bind.annotation.RestController;

import com.ram.app.model.Team;
import com.ram.app.repository.TeamRepository;

@RestController
@RequestMapping(PlayerController.BASE_URL)
public class TeamController {

	public static final String BASE_URL = "/auction";
	
	@Autowired
	private TeamRepository teamRepository;
	
	@GetMapping
	@RequestMapping("/teams")
	@ResponseStatus(HttpStatus.OK)
	public List<Team> getTeam() {
		return teamRepository.findAll().stream().collect(Collectors.toList());
	}
}
