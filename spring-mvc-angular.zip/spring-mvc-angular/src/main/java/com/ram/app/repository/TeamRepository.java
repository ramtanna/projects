package com.ram.app.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.ram.app.model.Team;
import java.lang.String;
import java.util.List;

@Repository
public interface TeamRepository extends JpaRepository<Team, Long> {

	List<Team> findByTeamName(String teamname);

}
