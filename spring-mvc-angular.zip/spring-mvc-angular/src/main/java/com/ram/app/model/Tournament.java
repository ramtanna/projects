package com.ram.app.model;

import java.util.HashSet;
import java.util.Set;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Transient;


@Entity
public class Tournament {

	@Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long tournamentId; 
	
	@Column(name="team_count")
	private int teamCount;
	
	@Column(name="tournament_name")
	private String name;
	
	@Column(name="venue")
	private String venue;
	
//	@OneToMany(cascade = CascadeType.ALL, mappedBy = "tournament", fetch=FetchType.LAZY)
	@Transient
	private Set<Team> teams = new HashSet<>();

	public Long getTournamentId() {
		return tournamentId;
	}

	public void setTournamentId(Long tournamentId) {
		this.tournamentId = tournamentId;
	}

	public int getTeamCount() {
		return teamCount;
	}

	public void setTeamCount(int teamCount) {
		this.teamCount = teamCount;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getVenue() {
		return venue;
	}

	public void setVenue(String venue) {
		this.venue = venue;
	}

	public Set<Team> getTeams() {
		return teams;
	}

	public void setTeams(Set<Team> teams) {
		this.teams = teams;
	}
	
	public Tournament() {
	}

	public Tournament(Long tournamentId) {
		this.tournamentId = tournamentId;
	}

	@Override
	public String toString() {
		return "Tournament [tournamentId=" + tournamentId + ", teamCount=" + teamCount + ", name=" + name + ", venue="
				+ venue + ", teams=" + teams + "]";
	}
	
	
	
}
