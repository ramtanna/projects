package com.ram.app.bootstrap;

import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.ApplicationListener;
import org.springframework.context.event.ContextRefreshedEvent;
import org.springframework.stereotype.Component;

import com.ram.app.model.Player;
import com.ram.app.model.Team;
import com.ram.app.model.Tournament;
import com.ram.app.repository.PlayerRepository;
import com.ram.app.repository.TeamRepository;
import com.ram.app.repository.TournamentRepository;
import com.ram.app.util.PlayerCategoryEnum;

@Component
public class Bootstrap implements ApplicationListener<ContextRefreshedEvent>{

	@Autowired
	private PlayerRepository playerRepository;
	@Autowired
	private TeamRepository teamRepository;
	@Autowired
	private TournamentRepository tournamentRepository;
	
	@Override
	public void onApplicationEvent(ContextRefreshedEvent event) {
		// TODO Auto-generated method stub
		init();
	}

	private void init(){
		
		
//		Tournament tournament = new Tournament();
//		tournament.setName("LPL");
//		tournament.setTeamCount(10);
//		tournament.setVenue("Kalyan");
		
//		Team team = new Team();
//		team.setTeamName("CSK");
////		team.setCaptainName("Ram Tanna");
//		team.setTotal(1000000);
//		team.setBalance(1000000);
//		team.setTournament(tournament);
//		
//		Team team2 = new Team();
//		team2.setTeamName("MI");
////		team2.setCaptainName("Ram Tanna");
//		team2.setTotal(1000000);
//		team.setBalance(1000000);
//		team2.setTournament(tournament);
		
//		Set<Team> teams = new HashSet<>();
//		teams.add(team);
		
//		tournament.setTeams(teams);

//		playerRepository.save(player);
//		teamRepository.save(team);
//		tournamentRepository.save(tournament);
		
//		Player player = new Player();
//		player.setPlayerName("Ram Tanna");
//		player.setCategory(PlayerCategoryEnum.Batsman);
//		player.setTournament(tournament);
//		//player.setTeam(team);
//		
//		Player player2 = new Player();
//		player2.setPlayerName("Vinit Somaiya");
//		player2.setCategory(PlayerCategoryEnum.All_Rounder);
//		player2.setTournament(tournament);
//		//player2.setTeam(team);
//		
//		
////		Set<Player> players = new HashSet<>();
////		players.add(player);
////		players.add(player2);
////		team.getPlayers().add(player);
////		team.getPlayers().add(player2);
//		teamRepository.save(team);
//		teamRepository.save(team2);
//
////		team.getPlayers().add(player);
////		team.getPlayers().add(player2);
//
////		teamRepository.save(team);
//		
//		Optional<Tournament> recipeOptional = tournamentRepository.findById(1l);
//
//        Tournament t = recipeOptional.get();
//        
//        Optional<Team> teamOptional = teamRepository.findById(1l);
//        Team t1 = teamOptional.get();
////        System.out.println(t1.toString());
////        System.out.println(t.getTeams());
//		
////		Tournament t1 = tournamentRepository.findById(1l).get();
////		System.out.println(t1.getTeams().size());
//        
//        playerRepository.save(player);
//        playerRepository.save(player2);
        
		
	}
	
	
}
