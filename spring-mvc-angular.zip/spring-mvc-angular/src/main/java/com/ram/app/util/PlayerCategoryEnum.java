package com.ram.app.util;

public enum PlayerCategoryEnum {

	Batsman("Batsman"), Bowler("Bowler"), All_Rounder("All_Rounder"), Captain("Captain"), Fresh("Fresh")
	, NA("NA"), Open("Open"), Group_A("Group A"), Group_B("Group B"), Team("Team");

	private final String value;

	PlayerCategoryEnum(final String value) {
		this.value = value;
	}

	/**
	 * @return the value
	 */
	public String getValue() {
		return value;
	}
}

