package com.ram.app;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpringMvcAngularApplication {

	public static void main(String[] args) {
		SpringApplication.run(SpringMvcAngularApplication.class, args);
	}
}
