package com.ram.app.dto;

public class PlayerBidDTO {

//	private String firstName;
//	private String lastName;
//	private PlayerCategoryEnum category;
	private double sellingPrice;
	private String teamName;
	
//	public String getFirstName() {
//		return firstName;
//	}
//	public void setFirstName(String firstName) {
//		this.firstName = firstName;
//	}
//	public String getLastName() {
//		return lastName;
//	}
//	public void setLastName(String lastName) {
//		this.lastName = lastName;
//	}
//	public PlayerCategoryEnum getCategory() {
//		return category;
//	}
//	public void setCategory(PlayerCategoryEnum category) {
//		this.category = category;
//	}
	public double getSellingPrice() {
		return sellingPrice;
	}
	public void setSellingPrice(double sellingPrice) {
		this.sellingPrice = sellingPrice;
	}
	public String getTeamName() {
		return teamName;
	}
	public void setTeamName(String teamName) {
		this.teamName = teamName;
	}
	@Override
	public String toString() {
		return "PlayerDTO [sellingPrice=" + sellingPrice + ", teamName=" + teamName + "]";
	}
	

}
