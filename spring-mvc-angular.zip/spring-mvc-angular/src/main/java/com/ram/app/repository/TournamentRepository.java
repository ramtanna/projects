package com.ram.app.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.ram.app.model.Tournament;

@Repository
public interface TournamentRepository extends JpaRepository<Tournament, Long>{

}
