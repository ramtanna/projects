package com.ram.app.service;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

import javax.transaction.Transactional;

import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.ram.app.dto.PlayerBidDTO;
import com.ram.app.dto.PlayerDTO;
import com.ram.app.dto.TeamDTO;
import com.ram.app.model.Player;
import com.ram.app.model.Team;
import com.ram.app.model.Tournament;
import com.ram.app.repository.PlayerRepository;
import com.ram.app.repository.TeamRepository;

@Service
public class AuctionServiceImpl implements IAuctionService {

	@Autowired
	private PlayerRepository playerRepository;

	@Autowired
	private TeamRepository teamRepository;

	@Transactional
	@Override
	public void purchasePlayer(Long playerId, PlayerBidDTO playerDTO) {

		Player player = playerRepository.getOne(playerId);
		
		Team team = teamRepository.findByTeamName(playerDTO.getTeamName()).get(0);
		team.setSpent(team.getSpent() + playerDTO.getSellingPrice());
		team.setBalance(team.getBalance() - playerDTO.getSellingPrice());
		
		teamRepository.save(team);

		player.setTeam(team);
		player.setSellingPrice(playerDTO.getSellingPrice());
		player.setStatus("SOLD");
		playerRepository.save(player);

	}
	
	@Override
	public TeamDTO getTeam(Long tournamentId, Long teamId) {
		
		List<Player> players = playerRepository.findByTournamentAndStatusAndTeam(new Tournament(tournamentId),"SOLD",new Team(teamId)).stream().collect(Collectors.toList());
		
		Team teamInfo = teamRepository.getOne(teamId);
		TeamDTO team = new TeamDTO();

		BeanUtils.copyProperties(teamInfo, team);
		
		if(players!=null & !players.isEmpty())
		{
		for (Player player : players) {
			
				PlayerDTO playerDTO = new PlayerDTO();
				BeanUtils.copyProperties(player, playerDTO);
				team.getPlayers().add(playerDTO);
		}
		}
		team.setNoOfPlayers(team.getPlayers().size());		
		return team;
	}

	@Override
	public List<TeamDTO> getTeamDashboard(Long tournamentId) {
		
		
//		List<Team> teamList = teamRepository.findAll();
//		List<TeamDTO> teams = new ArrayList<>();
//		for(Team team:teamList){
//			TeamDTO teamDTO = new TeamDTO();
//			BeanUtils.copyProperties(team, teamDTO);
//			teams.add(teamDTO);
//		}
//		
//		List<Player> players = playerRepository.findByTournamentAndStatus(new Tournament(tournamentId),"SOLD").stream().collect(Collectors.toList());
//		
//		for(Player player : players){
//			
//		}
		
		
		List<Player> players = playerRepository.findByTournamentAndStatus(new Tournament(tournamentId),"SOLD").stream().collect(Collectors.toList());
		
		Map<String, List<Player>> playersByTeamMap = players.stream()
		        .collect(Collectors.groupingBy(player -> player.getTeam().getTeamName()));
		List<TeamDTO> teams = new ArrayList<>();
		for (Map.Entry<String, List<Player>> entry : playersByTeamMap.entrySet()) {
			if(!entry.getValue().isEmpty()){
			TeamDTO team = new TeamDTO();
			BeanUtils.copyProperties(entry.getValue().get(0).getTeam(), team);

			for(Player player :entry.getValue()){
				PlayerDTO playerDTO = new PlayerDTO();
				BeanUtils.copyProperties(player, playerDTO);
				team.getPlayers().add(playerDTO);
			}
			team.setNoOfPlayers(team.getPlayers().size());
			teams.add(team);
			
			}
		}
		
		return teams;
	}

}
