package com.ram.app.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.ram.app.model.Player;
import com.ram.app.model.Team;
import java.util.List;
import com.ram.app.model.Tournament;
import java.lang.String;

@Repository
public interface PlayerRepository extends JpaRepository<Player, Long>{
	
	List<Player> findByTeam(Team team);
	
//	List<Player> findByTournamentAndStatusIsNull(Tournament tournament);

	List<Player> findByTournamentAndStatusAndTeam(Tournament tournament, String status, Team team);
	
	List<Player> findByTournamentAndStatus(Tournament tournament, String status);
	
	List<Player> findByTournamentAndStatusIsNotLike(Tournament tournament,String status);
	
//	List<Player> findByTournament(Tournament tournament);
	
	

}
