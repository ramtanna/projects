package com.ram.app.service;

import java.util.List;

import org.springframework.stereotype.Service;

import com.ram.app.dto.PlayerBidDTO;
import com.ram.app.dto.TeamDTO;

@Service
public interface IAuctionService {

	public void purchasePlayer(Long playerId, PlayerBidDTO player);
	
	public TeamDTO getTeam(Long tournamentId, Long teamId);
	
	public List<TeamDTO> getTeamDashboard(Long tournamentId);
	
	
	
}
