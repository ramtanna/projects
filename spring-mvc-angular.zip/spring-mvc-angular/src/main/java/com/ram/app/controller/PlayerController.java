package com.ram.app.controller;

import java.util.List;
import java.util.stream.Collectors;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseStatus;
import org.springframework.web.bind.annotation.RestController;

import com.ram.app.model.Player;
import com.ram.app.model.Tournament;
import com.ram.app.repository.PlayerRepository;

@RestController
@RequestMapping(PlayerController.BASE_URL)
public class PlayerController {

	public static final String BASE_URL = "/auction";

	@Autowired
	private PlayerRepository playerRepository;
	
	@GetMapping
	@RequestMapping("/tournament/{tournamentId}/players")
	@ResponseStatus(HttpStatus.OK)
	public List<Player> getPlayers(@PathVariable Long tournamentId) {
		// List<Player> playerList = playerRepository.findAll().stream().collect(Collectors.toList());
		List<Player> playerList = playerRepository.findByTournamentAndStatusIsNotLike(new Tournament(tournamentId),"SOLD").stream().collect(Collectors.toList());
		return playerList;
	}
	

}
