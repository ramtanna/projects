package com.ram.app.service;

public interface IPlayerService {

	
}
