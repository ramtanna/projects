define([], function()
{
    return {
        defaultRoutePath: '/',
        routes: {
        	'/auction': {
                templateUrl: './views/auction.html',
                dependencies: [
                	'factory/auctionFactory',
                    'controllers/AuctionController'
                ]
            },
        	
        	
        	'/1': {
                templateUrl: './views/home.html',
                dependencies: [
                    'controllers/HomeViewController'
                ]
            },
            '/2': {
                templateUrl: 'resources/views/about.html',
                dependencies: [
                    'controllers/AboutViewController',
                    'directives/app-color'
                ]
            },
            '/3': {
                templateUrl: 'resources/views/contact.html',
                dependencies: [
                    'controllers/ContactViewController',
                    'directives/date-picker'
                ]
            },
            '/enquiry': {
                templateUrl: 'resources/views/addEnquiry.html',
                dependencies: [
                               'factory/enquiryFactory',
                    'controllers/AddEnquiryController'
                ]
            },
            '/viewEnquiries': {
                templateUrl: 'resources/views/viewEnquiries.html',
                dependencies: [
                               'factory/enquiryFactory',
                               'controllers/ViewEnquiriesController'
                   
                ]
            },
            '/newHighlights': {
                templateUrl: 'resources/views/addHighlights.html',
                dependencies: [
                               'factory/highlightsFactory',
                    'controllers/AddHighlightsController'
                ]
            },
            '/modifyHighlights': {
                templateUrl: 'resources/views/modifyHighlights.html',
                dependencies: [
                               'factory/highlightsFactory',
                    'controllers/ModifyHighlightsController'
                ]
            },
            '/newCourse': {
                templateUrl: 'resources/views/addCourse.html',
                dependencies: [
                               'factory/courseFactory',
                    'controllers/AddCourseController'
                ]
            },
            '/modifyCourse': {
                templateUrl: 'resources/views/modifyCourse.html',
                dependencies: [
                               'factory/courseFactory',
                    'controllers/ModifyCourseController'
                ]
            }
        }
    };
});