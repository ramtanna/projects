'use strict';

angular.module('app').factory('AuctionFactory', ['$http', '$q', function($http, $q){

   var factory = {
		   getPlayers: getPlayers,
		   getTeams: getTeams,
		   submitBid: submitBid,
		   getTeam: getTeam,
		   getTeamDashboard:getTeamDashboard
//		   getCourseObject: getCourseObject,
//		   createCourse: createCourse,
//		   getCourses: getCourses,
//		   updateCourses: updateCourses
    };

    return factory;
    
  function getPlayers() {
  var deferred = $q.defer();
  $http.get('/auction/tournament/1/players')
      .then(
      function (response) {
          deferred.resolve(response.data);
      },
      function(errResponse){
          console.error('Error while fetching Players');
          deferred.reject(errResponse);
      }
  );
  return deferred.promise;
}
  
  
  
  function getTeams() {
	  var deferred = $q.defer();
	  $http.get('/auction/teams')
	      .then(
	      function (response) {
	          deferred.resolve(response.data);
	      },
	      function(errResponse){
	          console.error('Error while fetching Players');
	          deferred.reject(errResponse);
	      }
	  );
	  return deferred.promise;
	}

function submitBid(player) {
var deferred = $q.defer();
$http.post('/auction/purchase/'+player.playerId, player)
    .then(
    function (response) {
        deferred.resolve(response.data);
    },
    function(errResponse){
        console.error('Error while placing a Bid');
        deferred.reject(errResponse);
    }
);
return deferred.promise;
}

function getTeam(teamId) {
	  var deferred = $q.defer();
	  $http.get('/auction/tournaments/1/teams/'+teamId)
	      .then(
	      function (response) {
	          deferred.resolve(response.data);
	      },
	      function(errResponse){
	          console.error('Error while fetching Players');
	          deferred.reject(errResponse);
	      }
	  );
	  return deferred.promise;
	}

function getTeamDashboard() {
	  var deferred = $q.defer();
	  $http.get('/auction/tournaments/1/teams')
	      .then(
	      function (response) {
	          deferred.resolve(response.data);
	      },
	      function(errResponse){
	          console.error('Error while fetching Players');
	          deferred.reject(errResponse);
	      }
	  );
	  return deferred.promise;
	}
  
//    function getCourseObject() {
//        var deferred = $q.defer();
//        $http.get('/cvci/getCourseObject')
//            .then(
//            function (response) {
//                deferred.resolve(response.data);
//            },
//            function(errResponse){
//                console.error('Error while fetching Users');
//                deferred.reject(errResponse);
//            }
//        );
//        return deferred.promise;
//    }
//
//    function createCourse(course) {
//        var deferred = $q.defer();
//        $http.post('/cvci/createCourse', course)
//            .then(
//            function (response) {
//                deferred.resolve(response.data);
//            },
//            function(errResponse){
//                console.error('Error while creating User');
//                deferred.reject(errResponse);
//            }
//        );
//        return deferred.promise;
//    }
//
//
//    function getCourses() {
//        var deferred = $q.defer();
//        $http.get('/cvci/getAllCourses')
//            .then(
//            function (response) {
//                deferred.resolve(response.data);
//            },
//            function(errResponse){
//                console.error('Error while fetching Users');
//                deferred.reject(errResponse);
//            }
//        );
//        return deferred.promise;
//    }
//    
//    function updateCourses(updatedCourses) {
//        var deferred = $q.defer();
//        $http.post('/CVCI/updateCourses', updatedCourses)
//            .then(
//            function (response) {
//                deferred.resolve(response.data);
//            },
//            function(errResponse){
//                console.error('Error while creating User');
//                deferred.reject(errResponse);
//            }
//        );
//        return deferred.promise;
//    }


}]);
