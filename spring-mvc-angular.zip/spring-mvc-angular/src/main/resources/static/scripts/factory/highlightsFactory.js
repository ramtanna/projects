'use strict';

angular.module('app').factory('HighlightFactory', ['$http', '$q', function($http, $q){

   var factory = {
		   getHighlightObject: getHighlightObject,
		   createHighlight: createHighlight,
		   getHighlights: getHighlights,
		   updateHighlights: updateHighlights
    };

    return factory;

    function getHighlightObject() {
        var deferred = $q.defer();
        $http.get('/cvci/getHighlightObject')
            .then(
            function (response) {
                deferred.resolve(response.data);
            },
            function(errResponse){
                console.error('Error while fetching Users');
                deferred.reject(errResponse);
            }
        );
        return deferred.promise;
    }

    function createHighlight(Highlight) {
        var deferred = $q.defer();
        $http.post('/cvci/createHighlight', Highlight)
            .then(
            function (response) {
                deferred.resolve(response.data);
            },
            function(errResponse){
                console.error('Error while creating User');
                deferred.reject(errResponse);
            }
        );
        return deferred.promise;
    }


    function getHighlights() {
        var deferred = $q.defer();
        $http.get('/cvci/getAllHighlights')
            .then(
            function (response) {
                deferred.resolve(response.data);
            },
            function(errResponse){
                console.error('Error while fetching Users');
                deferred.reject(errResponse);
            }
        );
        return deferred.promise;
    }
    
    function updateHighlights(updatedHighlights) {
        var deferred = $q.defer();
        $http.post('/cvci/updateHighlights', updatedHighlights)
            .then(
            function (response) {
                deferred.resolve(response.data);
            },
            function(errResponse){
                console.error('Error while creating User');
                deferred.reject(errResponse);
            }
        );
        return deferred.promise;
    }

    

}]);
