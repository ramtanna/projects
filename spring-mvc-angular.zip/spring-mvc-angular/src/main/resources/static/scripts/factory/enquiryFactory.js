'use strict';

angular.module('app').factory('EnquiryFactory', ['$http', '$q', function($http, $q){

   var factory = {
		   getEnquiryObject: getEnquiryObject,
		   createEnquiry: createEnquiry,
		   getEnquiries: getEnquiries,
		   updateEnquiries: updateEnquiries
    };

    return factory;

    function getEnquiryObject() {
        var deferred = $q.defer();
        $http.get('/cvci/getEnquiryObject')
            .then(
            function (response) {
                deferred.resolve(response.data);
            },
            function(errResponse){
                console.error('Error while fetching Users');
                deferred.reject(errResponse);
            }
        );
        return deferred.promise;
    }

    function createEnquiry(enquiry) {
        var deferred = $q.defer();
        $http.post('/cvci/createEnquiry', enquiry)
            .then(
            function (response) {
                deferred.resolve(response.data);
            },
            function(errResponse){
                console.error('Error while creating User');
                deferred.reject(errResponse);
            }
        );
        return deferred.promise;
    }


    function getEnquiries() {
        var deferred = $q.defer();
        $http.get('/CVCI/getAllEnquiries')
            .then(
            function (response) {
                deferred.resolve(response.data);
            },
            function(errResponse){
                console.error('Error while fetching Users');
                deferred.reject(errResponse);
            }
        );
        return deferred.promise;
    }
    
    function updateEnquiries(updatedEnquiries) {
        var deferred = $q.defer();
        $http.post('/cvci/updateEnquiries', updatedEnquiries)
            .then(
            function (response) {
                deferred.resolve(response.data);
            },
            function(errResponse){
                console.error('Error while creating User');
                deferred.reject(errResponse);
            }
        );
        return deferred.promise;
    }

    
//    function updateUser(user, id) {
//        var deferred = $q.defer();
//        $http.put(REST_SERVICE_URI+id, user)
//            .then(
//            function (response) {
//                deferred.resolve(response.data);
//            },
//            function(errResponse){
//                console.error('Error while updating User');
//                deferred.reject(errResponse);
//            }
//        );
//        return deferred.promise;
//    }
//
//    function deleteUser(id) {
//        var deferred = $q.defer();
//        $http.delete(REST_SERVICE_URI+id)
//            .then(
//            function (response) {
//                deferred.resolve(response.data);
//            },
//            function(errResponse){
//                console.error('Error while deleting User');
//                deferred.reject(errResponse);
//            }
//        );
//        return deferred.promise;
//    }

}]);
