'use strict';

angular.module('app').factory('CourseFactory', ['$http', '$q', function($http, $q){

   var factory = {
		   getCourseObject: getCourseObject,
		   createCourse: createCourse,
		   getCourses: getCourses,
		   updateCourses: updateCourses
    };

    return factory;

    function getCourseObject() {
        var deferred = $q.defer();
        $http.get('/cvci/getCourseObject')
            .then(
            function (response) {
                deferred.resolve(response.data);
            },
            function(errResponse){
                console.error('Error while fetching Users');
                deferred.reject(errResponse);
            }
        );
        return deferred.promise;
    }

    function createCourse(course) {
        var deferred = $q.defer();
        $http.post('/cvci/createCourse', course)
            .then(
            function (response) {
                deferred.resolve(response.data);
            },
            function(errResponse){
                console.error('Error while creating User');
                deferred.reject(errResponse);
            }
        );
        return deferred.promise;
    }


    function getCourses() {
        var deferred = $q.defer();
        $http.get('/cvci/getAllCourses')
            .then(
            function (response) {
                deferred.resolve(response.data);
            },
            function(errResponse){
                console.error('Error while fetching Users');
                deferred.reject(errResponse);
            }
        );
        return deferred.promise;
    }
    
    function updateCourses(updatedCourses) {
        var deferred = $q.defer();
        $http.post('/CVCI/updateCourses', updatedCourses)
            .then(
            function (response) {
                deferred.resolve(response.data);
            },
            function(errResponse){
                console.error('Error while creating User');
                deferred.reject(errResponse);
            }
        );
        return deferred.promise;
    }


}]);
