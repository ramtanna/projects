'use strict';

angular.module('app').controller('AddCourseController',['$scope','CourseFactory',function($scope,CourseFactory){
		
	
		$scope.course={};
		
		$scope.courseCategories = ["Application Courses","Hardware/Networking","Professional Courses","IT Syllabus Courses","Goverment certified Courses","Diploma/Advc Diploma Courses"];
		
		
		getNewCourse();

		  function getNewCourse(){
		    	CourseFactory.getCourseObject()
		            .then(
		            function(data) {
		            	 $scope.course = data;
		            	 $scope.course.courseCategory=$scope.courseCategories[0];
		            },
		            function(errResponse){
		                alert('Error while fetching Users');
		            }
		        );
		    }
		
		
            $scope.submitCourse = function() {
            	 createCourse($scope.course);
            };
            
           
            function createCourse(course){
            	CourseFactory.createCourse(course)
                    .then(
                    		function(data) {
                    			alert('Course created successfully');
                            },
                    function(errResponse){
                        alert('Error while creating User');
                    }
                );
            }
        }
    ]);
