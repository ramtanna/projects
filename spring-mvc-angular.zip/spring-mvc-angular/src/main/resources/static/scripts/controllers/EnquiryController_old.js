define(['app'], function(app)
{
	app.controller('EnquiryController',['$scope','$http','EnquiryService',function($scope,$http,EnquiryService){
		
		
		   fetchAllUsers();

		    function fetchAllUsers(){
		    	EnquiryService.fetchAllUsers()
		            .then(
		            function(d) {
		            	  console.error('fetching Users');
		            },
		            function(errResponse){
		                console.error('Error while fetching Users');
		            }
		        );
		    }
		
		
		
		$scope.enquiry={};
		
		 $http.get('/CVCI/getEnquiryObject')
            .then(
            function (response) {
            	$scope.enquiry = response.data;
            	alert(JSON.stringify($scope.enquiry));
            },
            function(errResponse){
                console.error('Error while fetching Users');
               
            }
        );
            
            
            $scope.submitEnquiry = function() {
            	 $http.post('/CVCI/createEnquiry', $scope.enquiry)
                 .then(
                 function (response) {
                 	 console.error('creating User');
                 },
                 function(errResponse){
                     console.error('Error while creating User');
                    
                 }
             );
	        };
            
           
            
            
            
            
            
            
            
            
            
        }
    ]);
});