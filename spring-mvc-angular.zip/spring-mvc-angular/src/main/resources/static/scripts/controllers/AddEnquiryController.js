'use strict';

angular.module('app').controller('AddEnquiryController',['$scope','EnquiryFactory',function($scope,EnquiryFactory){
		
		
		$scope.enquiry={};
		
		getNewEnquiry();

		  function getNewEnquiry(){
		    	EnquiryFactory.getEnquiryObject()
		            .then(
		            function(data) {
		            	 $scope.enquiry = data;
		            },
		            function(errResponse){
		                alert('Error while fetching Users');
		            }
		        );
		    }
		
		
            $scope.submitEnquiry = function() {
            	 createEnquiry($scope.enquiry);
            };
            
           
            function createEnquiry(enquiry){
            	EnquiryFactory.createEnquiry(enquiry)
                    .then(
                    		function(data) {
                    			alert('Enquiry created successfully');
                            },
                    function(errResponse){
                        alert('Error while creating User');
                    }
                );
            }
        }
    ]);
