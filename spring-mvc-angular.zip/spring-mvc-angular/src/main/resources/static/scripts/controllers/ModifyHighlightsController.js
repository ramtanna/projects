'use strict';

angular.module('app').controller('ModifyHighlightsController',['$scope','HighlightFactory',function($scope,HighlightFactory){
		
		
		$scope.highlights=[];
		
		$scope.updatedHighlights=[];
		
		getHighlights();

		  function getHighlights(){
		    	HighlightFactory.getHighlights()
		            .then(
		            function(data) {
		            	 $scope.highlights = data;
		            },
		            function(errResponse){
		                alert('Error while fetching Users');
		            }
		        );
		    }
		  
		  
		  $scope.addToUpdateList = function(highlight) {
			  
			  
			  if($scope.updatedHighlights.length==0){
				  $scope.updatedHighlights.push(highlight);  
			  }
			  else
			  {
			  var existFlag = false;
			  
			  for(var i=0;i<$scope.updatedHighlights.length;i++){
				  if($scope.updatedHighlights[i].highlightId == highlight.highlightId){
					  existFlag=true;
					  break;  
				  }  
			  }
			  
			  if(!existFlag){
				  $scope.updatedHighlights.push(highlight);  
			  }
		  }
	     };
         
         
         $scope.updateHighlights = function() {
        	 
        	 if($scope.updatedHighlights.length>0){
        		 updateAllHighlights($scope.updatedHighlights);
        	 }
         };
         
         function updateAllHighlights(highlights){
         	HighlightFactory.updateHighlights(highlights)
                 .then(
                 		function(data) {
                 			alert('highlights Updated successfully');
                 			$scope.updatedHighlights = [];
                         },
                 function(errResponse){
                     alert('Error while creating User');
                 }
             );
         }
         

            
         
        }
    ]);
