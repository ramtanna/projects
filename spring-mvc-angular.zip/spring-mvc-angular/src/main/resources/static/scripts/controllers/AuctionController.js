'use strict';

angular.module('app').controller('AuctionController',['$scope','AuctionFactory',function($scope,AuctionFactory){
		
		

		
		bootstrap();

		  function bootstrap(){
			  
				$scope.players={};
				$scope.player = {};
				$scope.teams={};
				$scope.team={};
				$scope.teamDashboard={};
				
			  $scope.playerKey = null;
			  
			  AuctionFactory.getPlayers()
		            .then(
		            function(data) {
		            	 $scope.players = data;
		            },
		            function(errResponse){
		                alert('Error while fetching Players');
		            }
		        );
			  
			  
			  AuctionFactory.getTeams()
	            .then(
	            function(data) {
	            	 $scope.teams = data;
	            },
	            function(errResponse){
	                alert('Error while fetching Teams');
	            }
	        );
			  
			  AuctionFactory.getTeamDashboard()
	            .then(
	            function(data) {
	            	 $scope.teamDashboard = data;
	            },
	            function(errResponse){
	                alert('Error while fetching Teams');
	            }
	        );
			  
		    }

		  
		  $scope.complete=function(string){
				
				var output=[];
				angular.forEach($scope.players,function(player){
					if(player.playerName.toLowerCase().indexOf(string.toLowerCase())>=0){
						output.push(player);
					}
				});
				$scope.filterPlayer=output;
			}
			$scope.fillTextbox=function(player){
				$scope.playerKey=player.playerName;
				$scope.filterPlayer=null;
				$scope.player = player;
			}
			
			 $scope.submitBid = function() {
				 
				 
				 
				 if(isNaN($scope.player.sellingPrice)){
					 alert('Invalid player price');
				 }
				 else if(!$scope.player.teamName){
					 alert('Invalid team name');
				 }
				 else if(!$scope.player.playerId){
					 alert('Invalid player ID');
				 }
				 else{
				 AuctionFactory.submitBid($scope.player)
                 .then(
                 		function(data) {
                 			alert('Details submitted successfully');
                 			bootstrap();
                         },
                 function(errResponse){
                     alert('Error while Submitting Bid');
                 }
             );
				 }
            };
            
            $scope.getTeamInfo = function(teamId) {
//            	alert(JSON.stringify($scope.team));
            	AuctionFactory.getTeam(teamId)
	            .then(
	            function(data) {
	            	 $scope.team = data;
	            },
	            function(errResponse){
	                alert('Error while fetching Players');
	            }
	        );
            	
            	
           };
            
           
           
//          function createCourse(course) {
//          var deferred = $q.defer();
//          $http.post('/cvci/createCourse', course)
//              .then(
//              function (response) {
//                  deferred.resolve(response.data);
//              },
//              function(errResponse){
//                  console.error('Error while creating User');
//                  deferred.reject(errResponse);
//              }
//          );
//          return deferred.promise;
//      }
			
//			$scope.complete=function(string){
//				
//				var output=[];
//				angular.forEach($scope.players,function(player){
//					if(player.firstName.toLowerCase().indexOf(string.toLowerCase())>=0){
//						output.push(player.firstName);
//					}
//				});
//				$scope.filterPlayer=output;
//			}
//			$scope.fillTextbox=function(p){
//				$scope.player=string;
//				$scope.filterPlayer=null;
//				
//			}
			 
			
//            $scope.submitEnquiry = function() {
//            	 createEnquiry($scope.enquiry);
//            };
//            
//           
//            function createEnquiry(enquiry){
//            	EnquiryFactory.createEnquiry(enquiry)
//                    .then(
//                    		function(data) {
//                    			alert('Enquiry created successfully');
//                            },
//                    function(errResponse){
//                        alert('Error while creating User');
//                    }
//                );
//            }
            
            
        }
    ]);
