'use strict';

angular.module('app').controller('AddHighlightsController',['$scope','HighlightFactory',function($scope,HighlightFactory){
		
		
		$scope.highlight={};
		
		getNewHighlight();

		  function getNewHighlight(){
		    	HighlightFactory.getHighlightObject()
		            .then(
		            function(data) {
		            	 $scope.highlight = data;
		            },
		            function(errResponse){
		                alert('Error while fetching Users');
		            }
		        );
		    }
		
		
            $scope.submitHighlight = function() {
            	createHighlight($scope.highlight);
            };
            
           
            function createHighlight(highlight){
            	HighlightFactory.createHighlight(highlight)
                    .then(
                    		function(data) {
                    			alert('highlight created successfully');
                            },
                    function(errResponse){
                        alert('Error while creating User');
                    }
                );
            }
            
        }
    ]);
