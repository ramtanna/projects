'use strict';

angular.module('app').controller('ViewEnquiriesController',['$scope','EnquiryFactory',function($scope,EnquiryFactory){
		
		
		$scope.enquiries=[];
		
		$scope.updatedEnquiries=[];
		
		getEnquiries();

		  function getEnquiries(){
		    	EnquiryFactory.getEnquiries()
		            .then(
		            function(data) {
		            	 $scope.enquiries = data;
		            },
		            function(errResponse){
		                alert('Error while fetching Users');
		            }
		        );
		    }
		  
		  
		  $scope.addToUpdateList = function(enquiry) {
			  
			  
			  if($scope.updatedEnquiries.length==0){
				  $scope.updatedEnquiries.push(enquiry);  
			  }
			  else
			  {
			  var existFlag = false;
			  
			  for(var i=0;i<$scope.updatedEnquiries.length;i++){
				  if($scope.updatedEnquiries[i].enquiryId == enquiry.enquiryId){
					  existFlag=true;
					  break;  
				  }  
			  }
			  
			  if(!existFlag){
				  $scope.updatedEnquiries.push(enquiry);  
			  }
		  }
	     };
         
         
         $scope.updateEnquiries = function() {
        	 
        	 if($scope.updatedEnquiries.length>0){
        	 updateAllEnquiry($scope.updatedEnquiries);
        	 }
         };
         
         function updateAllEnquiry(enquiries){
         	EnquiryFactory.updateEnquiries(enquiries)
                 .then(
                 		function(data) {
                 			alert('Enquiry Updated successfully');
                 			$scope.updatedEnquiries = [];
                         },
                 function(errResponse){
                     alert('Error while creating User');
                 }
             );
         }
         
//            $scope.submitEnquiry = function() {
//            	 createEnquiry($scope.enquiry);
//            };
//            
//           
//            function createEnquiry(enquiry){
//            	EnquiryFactory.createEnquiry(enquiry)
//                    .then(
//                    		function(data) {
//                    			alert('creating User');
//                            },
//                    function(errResponse){
//                        alert('Error while creating User');
//                    }
//                );
//            }
//            
            


   
         
   
         
        }
    ]);
