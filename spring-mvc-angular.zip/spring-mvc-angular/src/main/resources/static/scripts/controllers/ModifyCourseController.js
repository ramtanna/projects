'use strict';

angular.module('app').controller('ModifyCourseController',['$scope','CourseFactory',function($scope,CourseFactory){
		
		
		$scope.courses=[];
		
		$scope.updatedCourses=[];
		
		$scope.courseCategories = ["Application Courses","Hardware/Networking","Professional Courses","IT Syllabus Courses","Goverment certified Courses","Diploma/Advc Diploma Courses"];
		
		getCourses();

		  function getCourses(){
		    	CourseFactory.getCourses()
		            .then(
		            function(data) {
		            	 $scope.courses = data;
		            },
		            function(errResponse){
		                alert('Error while fetching Users');
		            }
		        );
		    }
		  
		  
		  $scope.addToUpdateList = function(course) {
			  
			  
			  if($scope.updatedCourses.length==0){
				  $scope.updatedCourses.push(course);  
			  }
			  else
			  {
			  var existFlag = false;
			  
			  for(var i=0;i<$scope.updatedCourses.length;i++){
				  if($scope.updatedCourses[i].courseId == course.courseId){
					  existFlag=true;
					  break;  
				  }  
			  }
			  
			  if(!existFlag){
				  $scope.updatedCourses.push(course);  
			  }
		  }
	     };
         
         
         $scope.updateCourses = function() {
        	 
        	 if($scope.updatedCourses.length>0){
        		 updateAllCourses($scope.updatedCourses);
        	 }
         };
         
         function updateAllCourses(courseId){
         	CourseFactory.updateCourses(courseId)
                 .then(
                 		function(data) {
                 			alert('courseId Updated successfully');
                 			$scope.updatedCourses = [];
                         },
                 function(errResponse){
                     alert('Error while creating User');
                 }
             );
         }
         

            
         
        }
    ]);
