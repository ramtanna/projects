require.config({
    baseUrl: './scripts',
    paths: {
		'angular': 'js/angular',
		'angular-route': 'js/angular-route',
		'bootstrap': '../lib/bootstrap/js/bootstrap.min',
		'jquery': 'js/jquery',
		'dirPagination': '../lib/pagination/dirPagination',
    },
	shim: {
		'app': {
			deps: ['angular', 'angular-route', 'bootstrap','dirPagination']
		},
		'angular-route': {
			deps: ['angular']
		},
		'bootstrap': {
			deps: ['jquery']
		},
		'dirPagination': {
			deps: ['angular']
		}
	}
});

require
(
    [
        'app'
    ],
    function(app)
    {
        angular.bootstrap(document, ['app']);
    }
);