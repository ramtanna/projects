'use strict';

angular.module('cabApp').controller('indexController',[ '$scope', 'cabFactory', function($scope, cabFactory) {

			$scope.drivers = {};
			$scope.customer = {};
			bootstrap();
			
			
			function bootstrap(){
				setDrivers();
			}
			
			$scope.bookCab = function() {
				 
				if(!$scope.customer.contactNo){
					 alert('Invalid Contact No');
				 }
				 else if(isNaN($scope.customer.latitude)){
					 alert('Invalid latitude');
				 }
				 else if(isNaN($scope.customer.longitude)){
					 alert('Invalid longitude');
				 }
				 else{
					 cabFactory.bookCab($scope.customer)
                .then(
                		function(data) {
                			alert('Cab Booked Successfully.\n'+
                			'Driver Details :\n'+
                			'Contact No : '+data.driver.contactNo+'\n'+
                			'Name : '+data.driver.name+'\n');
                			bootstrap();
                        },
                function(errResponse){
                        	if(errResponse.data.errorCode == 'LNCAB0002'){
                        		alert('Sorry! No cabs found in your area. Please try after sometime.');
                        	}
                        	else if(errResponse.data.errorCode == 'LNCAB0001'){
                        		alert('Invalid Contact Number. If you are a new user then kindly register.');
                        	}
                        	else{
                        		alert('Something went wrong while booking a cab.');
                        	}
                }
            );
				 }
           };
			
			
			
			function setDrivers(){
				  cabFactory.getDrivers()
					.then(function(data) {
					$scope.drivers = data;
				}, function(errResponse) {
					alert('Error while fetching Driver Report');
				});
			  }
			
} ]);
