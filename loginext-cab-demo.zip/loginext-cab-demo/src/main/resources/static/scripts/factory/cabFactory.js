'use strict';

angular.module('cabApp').factory('cabFactory', ['$http', '$q', function($http, $q){

   var factory = {
		   getDrivers: getDrivers,
		   bookCab: bookCab
    };

    return factory;
    
  function getDrivers() {
  var deferred = $q.defer();
  $http.get('/loginext/drivers')
      .then(
      function (response) {
          deferred.resolve(response.data);
      },
      function(errResponse){
          console.error('Error while fetching Driver Report');
          deferred.reject(errResponse);
      }
  );
  return deferred.promise;
}
  
function bookCab(customer) {
var deferred = $q.defer();
$http.post('/loginext/cabs/book', customer)
    .then(
    function (response) {
        deferred.resolve(response.data);
    },
    function(errResponse){
        console.error('Error while booking a cab');
        deferred.reject(errResponse);
    }
);
return deferred.promise;
}



}]);
