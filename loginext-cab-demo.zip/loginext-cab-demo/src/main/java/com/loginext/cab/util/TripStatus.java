package com.loginext.cab.util;

public enum TripStatus {

	IN_PROCESS,COMPLETED;
}
