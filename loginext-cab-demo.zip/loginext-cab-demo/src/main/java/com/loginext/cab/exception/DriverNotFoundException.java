package com.loginext.cab.exception;

import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.ResponseStatus;

@ResponseStatus(code=HttpStatus.NOT_FOUND)
public class DriverNotFoundException extends RuntimeException{

	/**
	 * 
	 */
	private static final long serialVersionUID = -4260974569239339514L;
	
	private String errorCode;

	public DriverNotFoundException() {
		super();
		// TODO Auto-generated constructor stub
	}

	public DriverNotFoundException(String errorCode) {
		this.errorCode = errorCode;
	}

	public String getErrorCode() {
		return errorCode;
	}

	public void setErrorCode(String errorCode) {
		this.errorCode = errorCode;
	}


}
