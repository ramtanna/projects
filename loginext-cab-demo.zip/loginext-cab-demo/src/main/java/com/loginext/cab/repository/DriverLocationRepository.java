package com.loginext.cab.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.loginext.cab.model.DriverLocation;

@Repository
public interface DriverLocationRepository extends JpaRepository<DriverLocation, String>{

	List<DriverLocation> findByDriverStatus(String driverStatus);
	
}
