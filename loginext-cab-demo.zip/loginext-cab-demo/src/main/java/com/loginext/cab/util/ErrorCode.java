package com.loginext.cab.util;

public interface ErrorCode {

	public static final String INVALID_CUSTOMER = "LNCAB0001";
	public static final String NO_DRIVER_FOUND = "LNCAB0002";
	public static final String NULL_CONTACT_NO = "LNCAB0003";
	public static final String NULL_LATITUDE = "LNCAB0004";
	public static final String NULL_LONGITUDE = "LNCAB0005";
}
