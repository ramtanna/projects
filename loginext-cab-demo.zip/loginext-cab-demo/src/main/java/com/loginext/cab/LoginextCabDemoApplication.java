package com.loginext.cab;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class LoginextCabDemoApplication {

	public static void main(String[] args) {
		SpringApplication.run(LoginextCabDemoApplication.class, args);
	}
}
