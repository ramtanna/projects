package com.loginext.cab.service;

import com.loginext.cab.dto.CabBookingRequestDto;
import com.loginext.cab.model.BookingDetail;

public interface ICabBookingService {

	public BookingDetail book(CabBookingRequestDto bookingRequest);

}
