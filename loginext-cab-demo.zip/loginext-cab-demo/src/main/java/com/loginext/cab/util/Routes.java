package com.loginext.cab.util;

public class Routes {

	public static final String LOGINEXT = "/loginext";
	public static final String CAB_BOOKING   = "/cabs/book";
	public static final String DRIVERS   = "/drivers";
	
}
