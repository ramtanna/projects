package com.loginext.cab.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.loginext.cab.model.DriverLocation;
import com.loginext.cab.service.IDriverService;
import com.loginext.cab.util.Routes;

import lombok.extern.slf4j.Slf4j;

@Slf4j
@RestController
@RequestMapping(path=Routes.LOGINEXT)
public class DriverController {

	@Autowired
	IDriverService driverService;
	
	/**
	 * The API returns all driver details along with their location and trip status. 
	 * @return
	 */
	@GetMapping
	@RequestMapping(path=Routes.DRIVERS)
	public List<DriverLocation> getDriverReport(){
		log.info("Fetching Driver Report.");
		return driverService.getDriverReport();
	}
	
	
}
