package com.loginext.cab.model;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.OneToOne;

import lombok.Data;

@Data
@Entity
public class DriverLocation {

	@Id
	private String contactNo;

	@OneToOne
	private BookingDetail bookingDetail;

	@Column
	private Double driverLatitude;

	@Column
	private Double driverLongitude;

	@Column
	private String location;
	
	@Column
	private String driverStatus;
	
	@OneToOne
	private Driver driver;
	
	
}
