package com.loginext.cab.util;

public enum DriverStatus {

	AVAILABLE,BUSY;
}
