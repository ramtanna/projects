package com.loginext.cab.model;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.OneToOne;

import lombok.Data;

@Data
@Entity
public class BookingDetail {

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Integer id;
	
	@Column
	private Double sourceLatitude;
	
	@Column
	private Double sourceLongitude;
	
	@Column
	private String tripStatus;
	
	@OneToOne
	private Driver driver;

	@OneToOne
	private Customer customer;

}
