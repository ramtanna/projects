package com.loginext.cab.controller;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseStatus;
import org.springframework.web.bind.annotation.RestController;

import com.loginext.cab.dto.CabBookingRequestDto;
import com.loginext.cab.model.BookingDetail;
import com.loginext.cab.service.ICabBookingService;
import com.loginext.cab.util.Routes;

import lombok.extern.slf4j.Slf4j;

@Slf4j
@RestController
@RequestMapping(Routes.LOGINEXT)
public class CabBookingController {

	@Autowired
	ICabBookingService bookingService;
	
	/**
	 * This API books the nearest cab for a customer using customer's latitude and longitude.
	 * @param request
	 * @return
	 */
	@PostMapping
	@RequestMapping(Routes.CAB_BOOKING)
	@ResponseStatus(HttpStatus.OK)
	public BookingDetail bookCab(@Valid @RequestBody CabBookingRequestDto request){
		log.info("Request Received for customer ID " + request.getContactNo());
		return bookingService.book(request);
	}
	
}
