package com.loginext.cab.service.impl;

import java.util.Optional;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.loginext.cab.dto.CabBookingRequestDto;
import com.loginext.cab.exception.DriverNotFoundException;
import com.loginext.cab.exception.InvalidCustomerException;
import com.loginext.cab.model.BookingDetail;
import com.loginext.cab.model.Customer;
import com.loginext.cab.model.Driver;
import com.loginext.cab.model.DriverLocation;
import com.loginext.cab.repository.BookingDetailRepository;
import com.loginext.cab.repository.CustomerRepository;
import com.loginext.cab.repository.DriverLocationRepository;
import com.loginext.cab.service.ICabBookingService;
import com.loginext.cab.service.IDriverService;
import com.loginext.cab.util.DriverStatus;
import com.loginext.cab.util.ErrorCode;
import com.loginext.cab.util.Message;
import com.loginext.cab.util.TripStatus;

import lombok.extern.slf4j.Slf4j;

@Slf4j
@Service
public class CabBookingServiceImpl implements ICabBookingService {

	@Autowired
	CustomerRepository customerRepo;

	@Autowired
	IDriverService driverService;

	@Autowired
	BookingDetailRepository bookingRepo;

	@Autowired
	DriverLocationRepository driverLocationRepo;
	
	@Autowired
	Message message;

	@Transactional
	@Override
	public BookingDetail book(CabBookingRequestDto bookingRequest) {

		log.info("Fetching Customer Details for Customer ID : " + bookingRequest.getContactNo());
		
		Optional<Customer> customerOption = customerRepo.findById(bookingRequest.getContactNo());
		if (!customerOption.isPresent()){
			throw new InvalidCustomerException(ErrorCode.INVALID_CUSTOMER);
		}
		Customer customer = customerOption.get();
		
		DriverLocation driverLocation = driverService.getNearestDriver(bookingRequest.getLatitude(),
				bookingRequest.getLongitude());

		if (driverLocation == null) {
			throw new DriverNotFoundException(ErrorCode.NO_DRIVER_FOUND);
		}

		log.info("Nearest driver from the location : (" + bookingRequest.getLatitude() + "," + bookingRequest.getLongitude() + ") is = " + driverLocation.getContactNo());
		
		BookingDetail bookingDetail = new BookingDetail();
		bookingDetail.setCustomer(customer);
		bookingDetail.setSourceLatitude(bookingRequest.getLatitude());
		bookingDetail.setSourceLongitude(bookingRequest.getLongitude());
		bookingDetail.setTripStatus(TripStatus.IN_PROCESS.toString());
		bookingDetail.setDriver(driverLocation.getDriver());
		bookingRepo.save(bookingDetail);

		driverLocation.setDriverStatus(DriverStatus.BUSY.toString());
		driverLocation.setBookingDetail(bookingDetail);
		driverLocationRepo.save(driverLocation);
		
		log.info("Cab Booked for Customer ID : " + bookingRequest.getContactNo());
		
		return bookingDetail;
	}

}
