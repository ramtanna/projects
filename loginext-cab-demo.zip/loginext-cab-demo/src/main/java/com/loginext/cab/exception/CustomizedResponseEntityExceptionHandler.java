package com.loginext.cab.exception;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Locale;
import java.util.ResourceBundle;

import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Component;
import org.springframework.validation.ObjectError;
import org.springframework.web.bind.MethodArgumentNotValidException;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.context.request.WebRequest;
import org.springframework.web.servlet.mvc.method.annotation.ResponseEntityExceptionHandler;

@ControllerAdvice
@Component
public class CustomizedResponseEntityExceptionHandler extends ResponseEntityExceptionHandler {

	private final String ERROR_SOURCE = "error_messages";

	@ExceptionHandler(InvalidCustomerException.class)
	public final ResponseEntity<ErrorDetails> handleInvalidCustomerException(InvalidCustomerException ex,
			WebRequest request) {
		String message = ResourceBundle.getBundle(ERROR_SOURCE, Locale.ROOT).getString(ex.getErrorCode());
		ErrorDetails errorDetails = new ErrorDetails(new Date(), message, request.getDescription(false),
				ex.getErrorCode());
		return new ResponseEntity<>(errorDetails, HttpStatus.BAD_REQUEST);
	}

	@ExceptionHandler(DriverNotFoundException.class)
	public final ResponseEntity<ErrorDetails> handleDriverNotFoundException(DriverNotFoundException ex,
			WebRequest request) {
		String message = ResourceBundle.getBundle(ERROR_SOURCE, Locale.ROOT).getString(ex.getErrorCode());
		ErrorDetails errorDetails = new ErrorDetails(new Date(), message, request.getDescription(false),
				ex.getErrorCode());
		return new ResponseEntity<>(errorDetails, HttpStatus.NOT_FOUND);
	}

	@Override
	protected ResponseEntity<Object> handleMethodArgumentNotValid(MethodArgumentNotValidException ex,
			HttpHeaders headers, HttpStatus status, WebRequest request) {

		List<String> errorCodes = new ArrayList<String>();
		List<String> errorMessages = new ArrayList<String>();
		for (ObjectError objectError : ex.getBindingResult().getAllErrors()) {
			errorCodes.add(objectError.getDefaultMessage());
			errorMessages.add(ResourceBundle.getBundle(ERROR_SOURCE, Locale.ROOT).getString(objectError.getDefaultMessage()));

		}
		ErrorsDetails errorDetails = new ErrorsDetails(new Date(), errorMessages, 
				request.getDescription(false), errorCodes);

		return new ResponseEntity(errorDetails, HttpStatus.BAD_REQUEST);
	}

}
