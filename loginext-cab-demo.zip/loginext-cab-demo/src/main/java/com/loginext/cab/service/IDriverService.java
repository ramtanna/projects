package com.loginext.cab.service;

import java.util.List;

import com.loginext.cab.model.DriverLocation;

public interface IDriverService {

	public DriverLocation getNearestDriver(double sourceLatitude, double sourceLongitude);
	
	public List<DriverLocation> getDriverReport();
	
}
