package com.loginext.cab.exception;

import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.ResponseStatus;

@ResponseStatus(code=HttpStatus.BAD_REQUEST)
public class InvalidCustomerException extends RuntimeException{

	/**
	 * 
	 */
	private static final long serialVersionUID = -4260974569239339514L;
	
	private String errorCode;

	public InvalidCustomerException() {
		super();
		// TODO Auto-generated constructor stub
	}

	public InvalidCustomerException(String errorCode) {
		this.errorCode = errorCode;
	}

	public String getErrorCode() {
		return errorCode;
	}

	public void setErrorCode(String errorCode) {
		this.errorCode = errorCode;
	}

	

}
