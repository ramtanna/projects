package com.loginext.cab.exception;

import java.util.Date;
import java.util.List;

import lombok.Data;

@Data
public class ErrorsDetails {

	private List<String> errorCodes;
	private List<String> messages;
	private String details;
	private Date timestamp;
	
	public ErrorsDetails(Date timestamp, List<String> messages, String details, List<String> errorCodes) {
		super();
		this.timestamp = timestamp;
		this.messages = messages;
		this.details = details;
		this.errorCodes = errorCodes;
	}
	
}
