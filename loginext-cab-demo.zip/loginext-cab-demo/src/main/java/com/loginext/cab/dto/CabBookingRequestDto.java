package com.loginext.cab.dto;

import javax.validation.constraints.NotNull;

import com.loginext.cab.util.ErrorCode;

import lombok.Data;

@Data
public class CabBookingRequestDto {

	@NotNull(message=ErrorCode.NULL_CONTACT_NO)
	private String contactNo;
	
	@NotNull(message=ErrorCode.NULL_LATITUDE)
	private Double latitude;
	
	@NotNull(message=ErrorCode.NULL_LONGITUDE)
	private Double longitude;
	
}
