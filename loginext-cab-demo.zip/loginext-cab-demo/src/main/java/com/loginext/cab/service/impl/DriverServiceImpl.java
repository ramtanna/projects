package com.loginext.cab.service.impl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.loginext.cab.model.DriverLocation;
import com.loginext.cab.repository.DriverLocationRepository;
import com.loginext.cab.service.IDriverService;
import com.loginext.cab.util.DistanceCalculator;
import com.loginext.cab.util.DriverStatus;

import lombok.extern.slf4j.Slf4j;

@Slf4j
@Service
public class DriverServiceImpl implements IDriverService {

	@Autowired
	DriverLocationRepository driverLocationRepository;

	@Override
	public DriverLocation getNearestDriver(double sourceLatitude, double sourceLongitude) {

		log.info("Finding nearest driver from the location : (" + sourceLatitude + "," + sourceLongitude + ")");
		
		List<DriverLocation> driverLocations = driverLocationRepository
				.findByDriverStatus(DriverStatus.AVAILABLE.toString());

		double shortestDistance = -1;
		DriverLocation nearestDriver = null;
		for (DriverLocation driverLocation : driverLocations) {

			double distance = DistanceCalculator.distance(sourceLatitude, sourceLongitude,
					driverLocation.getDriverLatitude(), driverLocation.getDriverLongitude());

			if (shortestDistance == -1 || distance < shortestDistance) {
				nearestDriver = driverLocation;
				shortestDistance = distance;
			}

		}
		
		return nearestDriver;
	}

	@Override
	public List<DriverLocation> getDriverReport() {
		return driverLocationRepository.findAll();
	}

}
